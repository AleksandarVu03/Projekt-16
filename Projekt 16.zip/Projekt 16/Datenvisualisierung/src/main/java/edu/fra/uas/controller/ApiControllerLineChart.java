package edu.fra.uas.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.fra.uas.model.LineChart;
import edu.fra.uas.repository.LineChartRepository;

@RestController
@RequestMapping(value = "/api/LineChart") // Hier finden wir alle gegeben Dateien in der JSON
public class ApiControllerLineChart {

	@Autowired
	private LineChartRepository repository;

	// GET request to retrieve all line chart data
	@GetMapping
	public ResponseEntity<List<LineChart>> getAll() {
		return new ResponseEntity<>(this.repository.findAll(), HttpStatus.OK);

	}

	// POST request to save line chart data
	@PostMapping()
	public ResponseEntity<String> saveLineChart(@RequestBody LineChart linechart) {
		this.repository.save(linechart);
		return new ResponseEntity<>("LineChart is saved", HttpStatus.ACCEPTED);
	}
}
