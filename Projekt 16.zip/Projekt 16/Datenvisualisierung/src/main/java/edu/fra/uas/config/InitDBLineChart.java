package edu.fra.uas.config;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.fra.uas.repository.LineChartRepository;

//This class initializes the database with default values for line chart if needed.

@Component
public class InitDBLineChart {

	@Autowired
	private LineChartRepository repository;

	@PostConstruct
	private void init() {

	}
}
