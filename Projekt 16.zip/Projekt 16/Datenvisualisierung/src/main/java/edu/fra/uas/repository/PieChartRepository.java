package edu.fra.uas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.fra.uas.model.PieChart;

public interface PieChartRepository extends JpaRepository<PieChart, Long> {

}
