package edu.fra.uas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.fra.uas.model.ScatterPointChart;

public interface ScatterPointChartRepository extends JpaRepository<ScatterPointChart, Long> {

}
