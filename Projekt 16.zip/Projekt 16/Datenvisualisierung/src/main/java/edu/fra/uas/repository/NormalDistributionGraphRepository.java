package edu.fra.uas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.fra.uas.model.NormalDistributionGraph;

public interface NormalDistributionGraphRepository extends JpaRepository<NormalDistributionGraph, Long> {
	

}
