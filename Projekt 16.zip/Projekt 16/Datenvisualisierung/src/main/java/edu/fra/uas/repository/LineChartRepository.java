package edu.fra.uas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.fra.uas.model.LineChart;

public interface LineChartRepository extends JpaRepository<LineChart, Long> {

}
