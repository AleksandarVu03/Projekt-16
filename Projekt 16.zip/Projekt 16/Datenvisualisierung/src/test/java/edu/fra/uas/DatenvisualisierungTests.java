package edu.fra.uas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatenvisualisierungTests {

	@Test
	void contextLoads() {
	}

}
